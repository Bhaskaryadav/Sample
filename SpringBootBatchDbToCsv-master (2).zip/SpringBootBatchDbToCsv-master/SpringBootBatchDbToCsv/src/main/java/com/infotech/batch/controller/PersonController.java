package com.infotech.batch.controller;

import java.io.IOException;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.infotech.batch.model.Person;

@RestController 
public class PersonController {
	
	Person person=null;
	
	public String sendingUserInformation(@RequestParam("userName") String userName, 
			@RequestParam("idProof") byte[] idProof) {
		
		person =new Person();
		person.setUserName(userName);
		person.setIdProof(idProof);
		System.out.println("inside Controller");
		System.out.println(person.getUserName()+","+person.getIdProof());
		return "Successfully Submitted";
		
	}

}
