package com.infotech.batch.processor;

import org.springframework.batch.item.ItemProcessor;

import com.infotech.batch.controller.PersonController;
import com.infotech.batch.model.Person;

public class PersonItenProcessor implements ItemProcessor<Person, Person>{
	
	PersonController pc=null;

	@Override
	public Person process(Person person) throws Exception {
		
		String userName = person.getUserName();
		byte[] idProof = person.getIdProof();
		pc=new PersonController();
		pc.sendingUserInformation(userName, idProof);
		return person;
	}
}
