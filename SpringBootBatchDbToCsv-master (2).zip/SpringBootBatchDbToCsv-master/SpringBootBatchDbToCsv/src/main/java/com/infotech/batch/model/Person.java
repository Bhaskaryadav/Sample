package com.infotech.batch.model;

public class Person {

	private String userName;
	private byte[] idProof;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public byte[] getIdProof() {
		return idProof;
	}
	public void setIdProof(byte[] idProof) {
		this.idProof = idProof;
	}
	
}
