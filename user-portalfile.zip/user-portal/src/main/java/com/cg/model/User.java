package com.cg.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User {
	@Id
	private int uno;
	@Override
	public String toString() {
		return "User [uno=" + uno + ", uname=" + uname + ", uaddr=" + uaddr + "]";
	}
	private String uname;
	private String uaddr;
	public int getUno() {
		return uno;
	}
	public void setUno(int uno) {
		this.uno = uno;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUaddr() {
		return uaddr;
	}
	public void setUaddr(String uaddr) {
		this.uaddr = uaddr;
	}

}
