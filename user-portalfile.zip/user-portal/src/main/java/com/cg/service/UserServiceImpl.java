package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.BookRepository;
import com.cg.dao.UserRepository;
import com.cg.exception.UserNotFoundException;
import com.cg.model.Book;
import com.cg.model.User;
@Service
public class UserServiceImpl implements UserService {
    @Autowired
	private UserRepository userRepository;
    @Autowired
    private BookRepository bookRepository;
	
	@Override
	public int insertUser(User user) {
		Optional<User> opsUser=userRepository.findById(user.getUno());
		if(opsUser.isPresent()) {
			throw new UserNotFoundException("User existed with given id:"+user.getUno());
		}
		int  userNo=userRepository.save(user).getUno();
		return userNo;
	}

	@Override
	public List<User> listAll() {
		
		List<User> users=userRepository.findAll();
		return users;
	}

	@Override
	public User findUser(int no) {
		Optional<User> opsUser=userRepository.findById(no);
		if(!opsUser.isPresent()) {
			throw new UserNotFoundException("User not existed with given id:"+no);
		}
		User user=opsUser.get();
		return user;
	}

	@Override
	public void deleteUser(int no) {
		User user=findUser(no);
		if(user!=null)
			userRepository.delete(user);
		
	}
	
	@Override
	public String savefile(Book book) {
		Book b=bookRepository.save(book);
		if(b==null) {
			return "Book not Stored";
		}else {
			return "Book Stored successfully";
		}
	}
	

	
	

}
