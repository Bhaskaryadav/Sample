package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.exception.UserNotFoundException;
import com.cg.model.Book;
import com.cg.model.User;



public interface UserService {
	
	public int insertUser(User user);
	public List<User> listAll();
	
	public User findUser(int no);
	public void deleteUser(int no);
	  public String savefile(Book book);
	
	

}
