package com.cg.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.model.Book;
import com.cg.model.User;
import com.cg.service.UserService;

//@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	@RequestMapping("/")
	public String home() {
		return "Welcome to Spring boot";
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public int saveUser(@RequestBody User user) {
		System.out.println("Inside Controller");
		System.out.println(user);
		int userNo=userService.insertUser(user);
		return userNo;
	}
	@RequestMapping(value="/allUsers")
	public List<User> getAllUsers(){
		System.out.println("get all users");
		List<User> listUsrs= userService.listAll();
		System.out.println(listUsrs.size());
		return listUsrs;
	}
	@RequestMapping(value="/getUser/{uid}")
	public User getUserbyId(@PathVariable String uid) {
		System.out.println("get by value:"+uid);
		int id=Integer.parseInt(uid);
		User user=userService.findUser(id);
		System.out.println(user);
		
		return user;
	}
    @RequestMapping(value="/delete/{id}")
	public String removeUser(@PathVariable String id) {
    	System.out.println("delete method"+id);
    	int uid=Integer.parseInt(id);
    	userService.deleteUser(uid);
		return "User Deleted Succesfully";
	}
    @RequestMapping(value="/save",method=RequestMethod.POST,consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
	 public String uploadFile(@RequestParam("file") MultipartFile file) {
		System.out.println("file uploaded successfully");
		return "Book saved Successfullay";
	}
	
	@RequestMapping(value="/student",method=RequestMethod.POST,consumes={ "multipart/form-data" })
	 public String uploadFiles(@RequestParam("file") MultipartFile file,@RequestParam("id") String id, @RequestParam("name") String name) {
		System.out.println("file uploaded successfully");
		int bid=Integer.parseInt(id);
		Book book=new Book();
		book.setId(bid);
		book.setName(name);
		try {
			book.setImage(file.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return userService.savefile(book);
		//return "Book saved Successfullay";
	}
}
